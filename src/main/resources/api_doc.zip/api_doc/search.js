let api = [];
api.push({
    alias: 'api',
    order: '1',
    desc: '',
    link: '',
    list: []
})
api[0].list.push({
    order: '1',
    desc: '新增保存部门',
});
api[0].list.push({
    order: '2',
    desc: '',
});
api[0].list.push({
    order: '3',
    desc: '',
});
api[0].list.push({
    order: '4',
    desc: '',
});
api[0].list.push({
    order: '5',
    desc: '',
});
api[0].list.push({
    order: '6',
    desc: '',
});
api[0].list.push({
    order: '7',
    desc: '项目管理   项目列表    我的组织页面初始化',
});
api[0].list.push({
    order: '8',
    desc: '项目管理   项目列表    我的组织页面初始化',
});
api[0].list.push({
    order: '9',
    desc: '',
});
api[0].list.push({
    order: '10',
    desc: '',
});
api[0].list.push({
    order: '11',
    desc: '团队成员-查询用户',
});
api[0].list.push({
    order: '12',
    desc: '添加用户（从部门添加和从组织添加）',
});
api[0].list.push({
    order: '13',
    desc: '移除用户（从部门移除和从组织移除）',
});
api[0].list.push({
    order: '14',
    desc: '切换当前组织',
});
api.push({
    alias: 'IndexController',
    order: '2',
    desc: '',
    link: '',
    list: []
})
api[1].list.push({
    order: '1',
    desc: '',
});
api.push({
    alias: 'MemberController',
    order: '3',
    desc: '',
    link: '',
    list: []
})
api[2].list.push({
    order: '1',
    desc: '账号停用',
});
api[2].list.push({
    order: '2',
    desc: '',
});
api[2].list.push({
    order: '3',
    desc: '账号停用',
});
api[2].list.push({
    order: '4',
    desc: '账号启用',
});
api[2].list.push({
    order: '5',
    desc: '账号删除',
});
api[2].list.push({
    order: '6',
    desc: '账号编辑',
});
api[2].list.push({
    order: '7',
    desc: '账号编辑',
});
api[2].list.push({
    order: '8',
    desc: '首页 &gt; 成员 &gt;vilson &gt;任务安排',
});
api[2].list.push({
    order: '9',
    desc: '',
});
api[2].list.push({
    order: '10',
    desc: '项目管理	我的项目 邀请新成员 模糊查询',
});
api[2].list.push({
    order: '11',
    desc: '项目管理	我的项目 邀请新成员页面初始化',
});
api[2].list.push({
    order: '12',
    desc: '项目管理	我的项目 项目设置 任务流转  规则创建页面初始化',
});
api[2].list.push({
    order: '13',
    desc: '',
});
api[2].list.push({
    order: '14',
    desc: '',
});
api.push({
    alias: 'AuthorityControoler',
    order: '4',
    desc: '',
    link: '',
    list: []
})
api[3].list.push({
    order: '1',
    desc: '系统设置/成员管理/访问授权/设置默认',
});
api[3].list.push({
    order: '2',
    desc: '系统设置/成员管理/访问授权/设置默认',
});
api[3].list.push({
    order: '3',
    desc: '系统设置/成员管理/访问授权/删除',
});
api[3].list.push({
    order: '4',
    desc: '系统设置/成员管理/访问授权',
});
api[3].list.push({
    order: '5',
    desc: '系统设置/成员管理/访问授权 编辑保存',
});
api[3].list.push({
    order: '6',
    desc: '系统设置/成员管理/访问授权 添加保存',
});
api[3].list.push({
    order: '7',
    desc: '系统设置	系统管理	菜单编辑',
});
api[3].list.push({
    order: '8',
    desc: '系统设置	系统管理	菜单启用',
});
api[3].list.push({
    order: '9',
    desc: '系统设置	系统管理	菜单启用',
});
api[3].list.push({
    order: '10',
    desc: '系统设置	系统管理	菜单禁用',
});
api[3].list.push({
    order: '11',
    desc: '系统设置	系统管理	菜单路由',
});
api[3].list.push({
    order: '12',
    desc: '系统设置	系统管理	菜单路由 添加菜单  节点初始化',
});
api[3].list.push({
    order: '13',
    desc: '',
});
api[3].list.push({
    order: '14',
    desc: '',
});
api[3].list.push({
    order: '15',
    desc: '系统设置	系统管理	菜单路由 添加菜单  保存',
});
api.push({
    alias: 'ProjectAssistController',
    order: '5',
    desc: '',
    link: '',
    list: []
})
api[4].list.push({
    order: '1',
    desc: '编辑版本库',
});
api[4].list.push({
    order: '2',
    desc: '',
});
api[4].list.push({
    order: '3',
    desc: '创建项目版本库',
});
api[4].list.push({
    order: '4',
    desc: '',
});
api[4].list.push({
    order: '5',
    desc: '',
});
api[4].list.push({
    order: '6',
    desc: '项目版本',
});
api[4].list.push({
    order: '7',
    desc: '',
});
api[4].list.push({
    order: '8',
    desc: '项目版本删除',
});
api[4].list.push({
    order: '9',
    desc: '',
});
api[4].list.push({
    order: '10',
    desc: '查询版本日志',
});
api[4].list.push({
    order: '11',
    desc: '关联任务',
});
api[4].list.push({
    order: '12',
    desc: '更改版本状态',
});
api[4].list.push({
    order: '13',
    desc: '项目版本编辑',
});
api[4].list.push({
    order: '14',
    desc: '项目版本读取',
});
api[4].list.push({
    order: '15',
    desc: '我的文件	移入回收站',
});
api[4].list.push({
    order: '16',
    desc: '我的文件	移入回收站',
});
api[4].list.push({
    order: '17',
    desc: '我的文件	改名',
});
api[4].list.push({
    order: '18',
    desc: '我的文件清单',
});
api[4].list.push({
    order: '19',
    desc: '每一个上传块都会包含如下分块信息： chunkNumber: 当前块的次序，第一个块是 1，注意不是从 0 开始的。 totalChunks: 文件被分成块的总数。 chunkSize: 分块大小，根据 totalSize 和这个值你就可以计算出总共的块数。注意最后一块的大小可能会比这个要大。 currentChunkSize: 当前块的大小，实际大小。 totalSize: 文件总大小。 identifier: 这个就是每个文件的唯一标示。 filename: 文件名。 relativePath: 文件夹上传的时候文件的相对路径属性。 一个分块可以被上传多次，当然这肯定不是标准行为，但是在实际上传过程中是可能发生这种事情的，这种重传也是本库的特性之一。  根据响应码认为成功或失败的： 200 文件上传完成 201 文加快上传成功 500 第一块上传失败，取消整个文件上传 507 服务器出错自动重试该文件块上传  此处仍不完善，未处理断点续传加密、秒传处理等。',
});
api[4].list.push({
    order: '20',
    desc: '',
});
api[4].list.push({
    order: '21',
    desc: '',
});
api.push({
    alias: 'CommonController',
    order: '6',
    desc: '',
    link: '',
    list: []
})
api[5].list.push({
    order: '1',
    desc: '通用下载请求',
});
api[5].list.push({
    order: '2',
    desc: '',
});
api.push({
    alias: 'ProjectController',
    order: '7',
    desc: '',
    link: '',
    list: []
})
api[6].list.push({
    order: '1',
    desc: '登录系统后，请求的索引',
});
api[6].list.push({
    order: '2',
    desc: '得到自己的项目日志',
});
api[6].list.push({
    order: '3',
    desc: '',
});
api[6].list.push({
    order: '4',
    desc: '',
});
api[6].list.push({
    order: '5',
    desc: '上传头像',
});
api[6].list.push({
    order: '6',
    desc: '',
});
api[6].list.push({
    order: '7',
    desc: '项目管理	我的项目 项目设置 项目删除（回收站）',
});
api[6].list.push({
    order: '8',
    desc: '项目管理	我的项目 项目设置 项目删除（回收站）',
});
api[6].list.push({
    order: '9',
    desc: '项目管理	我的项目 项目设置 项目删除恢复（回收站）',
});
api[6].list.push({
    order: '10',
    desc: '项目管理	我的项目 项目设置 项目归档',
});
api[6].list.push({
    order: '11',
    desc: '项目管理	已归档项目  取消归档',
});
api[6].list.push({
    order: '12',
    desc: '',
});
api[6].list.push({
    order: '13',
    desc: '项目管理	我的项目 项目设置 编辑保存',
});
api[6].list.push({
    order: '14',
    desc: '',
});
api[6].list.push({
    order: '15',
    desc: '项目管理	我的项目 项目设置打开',
});
api[6].list.push({
    order: '16',
    desc: '项目管理	我的项目 点击项目进行详细页面初始化',
});
api[6].list.push({
    order: '17',
    desc: '项目管理	我的项目 加入/取消收藏',
});
api[6].list.push({
    order: '18',
    desc: '项目管理	我的项目 页面初始化',
});
api[6].list.push({
    order: '19',
    desc: '',
});
api[6].list.push({
    order: '20',
    desc: '项目管理  基础设置  项目模板  项目模板删除',
});
api[6].list.push({
    order: '21',
    desc: '项目管理  基础设置  项目模板  项目模板编辑保存',
});
api[6].list.push({
    order: '22',
    desc: '',
});
api[6].list.push({
    order: '23',
    desc: '',
});
api[6].list.push({
    order: '24',
    desc: '',
});
api[6].list.push({
    order: '25',
    desc: '项目管理  基础设置  项目模板  制作项目模板保存',
});
api[6].list.push({
    order: '26',
    desc: '创建新项目-&gt;保存',
});
api[6].list.push({
    order: '27',
    desc: '',
});
api[6].list.push({
    order: '28',
    desc: '',
});
api[6].list.push({
    order: '29',
    desc: '',
});
api[6].list.push({
    order: '30',
    desc: '',
});
api.push({
    alias: 'NodeController',
    order: '8',
    desc: '',
    link: '',
    list: []
})
api[7].list.push({
    order: '1',
    desc: '',
});
api.push({
    alias: 'NotifyController',
    order: '9',
    desc: '',
    link: '',
    list: []
})
api[8].list.push({
    order: '1',
    desc: '',
});
api[8].list.push({
    order: '2',
    desc: '',
});
api[8].list.push({
    order: '3',
    desc: '',
});
api[8].list.push({
    order: '4',
    desc: '',
});
api[8].list.push({
    order: '5',
    desc: '项目管理	消息提醒 页面初始化',
});
api[8].list.push({
    order: '6',
    desc: '',
});
api.push({
    alias: 'TaskFileController',
    order: '10',
    desc: '',
    link: '',
    list: []
})
api[9].list.push({
    order: '1',
    desc: '任务模板下载',
});
api[9].list.push({
    order: '2',
    desc: '文件上传',
});
api.push({
    alias: 'TaskController',
    order: '11',
    desc: '',
    link: '',
    list: []
})
api[10].list.push({
    order: '1',
    desc: '项目管理	我的项目 项目打开 任务清单 打开任务详情 设置任务结束时间、备注、优先级',
});
api[10].list.push({
    order: '2',
    desc: '项目管理	我的项目 项目打开 任务清单 打开任务详情 设置任务结束时间、备注、优先级',
});
api[10].list.push({
    order: '3',
    desc: '项目管理	我的项目 项目打开 任务清单 打开任务详情 设置任务结束时间、备注、优先级',
});
api[10].list.push({
    order: '4',
    desc: '项目管理	我的项目 项目打开 任务清单 打开任务详情 添加评论',
});
api[10].list.push({
    order: '5',
    desc: '项目管理	我的项目 项目打开 任务清单 打开任务详情 编辑工时',
});
api[10].list.push({
    order: '6',
    desc: '',
});
api[10].list.push({
    order: '7',
    desc: '',
});
api[10].list.push({
    order: '8',
    desc: '项目管理	我的项目 项目打开 任务清单 打开任务详情 编辑工时',
});
api[10].list.push({
    order: '9',
    desc: '项目管理	我的项目 项目打开 任务清单 打开任务详情 添加工时',
});
api[10].list.push({
    order: '10',
    desc: '',
});
api[10].list.push({
    order: '11',
    desc: '未完成 项目管理	我的项目 项目打开 任务清单 打开任务详情 添加子任务',
});
api[10].list.push({
    order: '12',
    desc: '项目管理	我的项目 项目打开 任务清单 打开任务详情 新建标签保存',
});
api[10].list.push({
    order: '13',
    desc: '项目管理	我的项目 项目打开 任务清单 打开任务详情 编辑标签保存',
});
api[10].list.push({
    order: '14',
    desc: '项目管理	我的项目 项目打开 任务清单 打开任务详情 新建标签保存',
});
api[10].list.push({
    order: '15',
    desc: '项目管理	我的项目 项目打开 任务清单 打开任务详情 添加加标签初始化',
});
api[10].list.push({
    order: '16',
    desc: '项目管理	我的项目 项目打开 任务清单 打开任务详情 添加加标签初始化',
});
api[10].list.push({
    order: '17',
    desc: '项目管理	我的项目 项目打开 任务清单 打开任务详情',
});
api[10].list.push({
    order: '18',
    desc: '项目管理	我的项目 项目打开 任务清单 打开任务详情',
});
api[10].list.push({
    order: '19',
    desc: '',
});
api[10].list.push({
    order: '20',
    desc: '',
});
api[10].list.push({
    order: '21',
    desc: '项目管理	我的项目 项目打开 任务清单 打开任务详情',
});
api[10].list.push({
    order: '22',
    desc: '',
});
api[10].list.push({
    order: '23',
    desc: '',
});
api[10].list.push({
    order: '24',
    desc: '',
});
api[10].list.push({
    order: '25',
    desc: '项目管理	我的项目 项目打开 任务清单',
});
api[10].list.push({
    order: '26',
    desc: '项目管理	我的项目 项目设置 任务流转 创建规则打开',
});
api[10].list.push({
    order: '27',
    desc: '项目管理	我的项目 项目设置 任务流转 编辑任务',
});
api[10].list.push({
    order: '28',
    desc: '项目管理	我的项目 项目设置 任务流转 创建规则打开',
});
api[10].list.push({
    order: '29',
    desc: '',
});
api[10].list.push({
    order: '30',
    desc: '项目管理	我的项目 项目设置 任务流转 创建规则保存',
});
api[10].list.push({
    order: '31',
    desc: '',
});
api[10].list.push({
    order: '32',
    desc: '',
});
api[10].list.push({
    order: '33',
    desc: '',
});
api[10].list.push({
    order: '34',
    desc: '',
});
api[10].list.push({
    order: '35',
    desc: '',
});
api[10].list.push({
    order: '36',
    desc: '',
});
api[10].list.push({
    order: '37',
    desc: '',
});
api[10].list.push({
    order: '38',
    desc: '',
});
api[10].list.push({
    order: '39',
    desc: '',
});
api.push({
    alias: 'TaskStageController',
    order: '12',
    desc: '',
    link: '',
    list: []
})
api[11].list.push({
    order: '1',
    desc: '',
});
api[11].list.push({
    order: '2',
    desc: '',
});
api[11].list.push({
    order: '3',
    desc: '',
});
api[11].list.push({
    order: '4',
    desc: '',
});
api[11].list.push({
    order: '5',
    desc: '保存任务流转',
});
api[11].list.push({
    order: '6',
    desc: '编辑任务流转',
});
api[11].list.push({
    order: '7',
    desc: '删除任务流转',
});
api.push({
    alias: 'LoginController',
    order: '13',
    desc: '',
    link: '',
    list: []
})
api[12].list.push({
    order: '1',
    desc: '登录方法',
});
api[12].list.push({
    order: '2',
    desc: '刷新Token',
});
api[12].list.push({
    order: '3',
    desc: '获取验证码',
});
api[12].list.push({
    order: '4',
    desc: '注册用户',
});
api[12].list.push({
    order: '5',
    desc: '修改密码',
});
api[12].list.push({
    order: '6',
    desc: '绑定号码',
});
api[12].list.push({
    order: '7',
    desc: '',
});
api[12].list.push({
    order: '8',
    desc: '',
});
document.onkeydown = keyDownSearch;
function keyDownSearch(e) {
    const theEvent = e;
    const code = theEvent.keyCode || theEvent.which || theEvent.charCode;
    if (code === 13) {
        const search = document.getElementById('search');
        const searchValue = search.value;
        let searchArr = [];
        for (let i = 0; i < api.length; i++) {
            let apiData = api[i];
            const desc = apiData.desc;
            if (desc.toLocaleLowerCase().indexOf(searchValue) > -1) {
                searchArr.push({
                    order: apiData.order,
                    desc: apiData.desc,
                    link: apiData.link,
                    alias: apiData.alias,
                    list: apiData.list
                });
            } else {
                let methodList = apiData.list || [];
                let methodListTemp = [];
                for (let j = 0; j < methodList.length; j++) {
                    const methodData = methodList[j];
                    const methodDesc = methodData.desc;
                    if (methodDesc.toLocaleLowerCase().indexOf(searchValue) > -1) {
                        methodListTemp.push(methodData);
                        break;
                    }
                }
                if (methodListTemp.length > 0) {
                    const data = {
                        order: apiData.order,
                        desc: apiData.desc,
                        alias: apiData.alias,
                        link: apiData.link,
                        list: methodListTemp
                    };
                    searchArr.push(data);
                }
            }
        }
        let html;
        if (searchValue === '') {
            const liClass = "";
            const display = "display: none";
            html = buildAccordion(api,liClass,display);
            document.getElementById('accordion').innerHTML = html;
        } else {
            const liClass = "open";
            const display = "display: block";
            html = buildAccordion(searchArr,liClass,display);
            document.getElementById('accordion').innerHTML = html;
        }
        const Accordion = function (el, multiple) {
            this.el = el || {};
            this.multiple = multiple || false;
            const links = this.el.find('.dd');
            links.on('click', {el: this.el, multiple: this.multiple}, this.dropdown);
        };
        Accordion.prototype.dropdown = function (e) {
            const $el = e.data.el;
            let $this = $(this), $next = $this.next();
            $next.slideToggle();
            $this.parent().toggleClass('open');
            if (!e.data.multiple) {
                $el.find('.submenu').not($next).slideUp("20").parent().removeClass('open');
            }
        };
        new Accordion($('#accordion'), false);
    }
}

function buildAccordion(apiData, liClass, display) {
    let html = "";
    if (apiData.length > 0) {
         for (let j = 0; j < apiData.length; j++) {
            html += '<li class="'+liClass+'">';
            html += '<a class="dd" href="' + apiData[j].alias + '.html#header">' + apiData[j].order + '.&nbsp;' + apiData[j].desc + '</a>';
            html += '<ul class="sectlevel2" style="'+display+'">';
            let doc = apiData[j].list;
            for (let m = 0; m < doc.length; m++) {
                html += '<li><a href="' + apiData[j].alias + '.html#_' + apiData[j].order + '_' + doc[m].order + '_' + doc[m].desc + '">' + apiData[j].order + '.' + doc[m].order + '.&nbsp;' + doc[m].desc + '</a> </li>';
            }
            html += '</ul>';
            html += '</li>';
        }
    }
    return html;
}